clear all
close all
clc
%对比时只需要将net文件中最后的计算函数对比就行
DRRC_main1;
DRRC_main2;
DRRC_main3;
DRRC_main4;
%DRRC_main5;