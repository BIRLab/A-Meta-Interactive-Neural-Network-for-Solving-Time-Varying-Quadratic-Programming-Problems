function y=AFlinear(E)
y=E;
