function y=LIVEvectoru(t,x)
% q=[sin(3*t);cos(3*t)];
% b=cos(2*t);
% y=[-q;b];
y=[-cos(2*t)
   -sin(t)
    sin(7*t)];