%%%%%%%%很明显，当tau=0时，VPRNN不能使误差收敛，Our可以
close all
clc
clear all
for iter=1:1
MINN;
ZNN;
VPRNN;
set(gca,'FontName','Times New Roman','FontSize',16,'LineWidth',1.5);
end


