
close all
clc
clear all
for iter=1:1
MINN1;
MINN2;
MINN3;
MINN4;
 legend('$\alpha _{ii}=0.1$','$\alpha _{ii}=0.2$','$\alpha _{ii}=0.3$','$\alpha _{ii}=0.4$'); 
set(gca,'FontName','Times New Roman','FontSize',16,'LineWidth',1);
end


