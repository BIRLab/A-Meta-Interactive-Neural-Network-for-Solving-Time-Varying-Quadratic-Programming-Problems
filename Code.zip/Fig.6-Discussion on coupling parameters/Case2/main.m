%%%%%%%%很明显，当tau=0时，耦合矩阵对角线值越小，收敛效果越好，起到tau的替代作用
close all
clc
clear all
for iter=1:1
MINN1;
MINN2;
MINN3;
MINN4;
MINN5;
MINN6;
 legend('$\alpha _{ii}=-4$','$\alpha _{ii}=-5$','$\alpha _{ii}=-6$','$\alpha _{ii}=-7$','$\alpha _{ii}=-8$','$\alpha _{ii}=-10$'); 
set(gca,'FontName','Times New Roman','FontSize',16,'LineWidth',1);
end


