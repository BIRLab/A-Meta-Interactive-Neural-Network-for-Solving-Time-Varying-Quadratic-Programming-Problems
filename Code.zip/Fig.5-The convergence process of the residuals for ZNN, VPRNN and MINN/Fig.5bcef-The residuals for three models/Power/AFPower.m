function y=AFPower(E)

y=E.^3;
