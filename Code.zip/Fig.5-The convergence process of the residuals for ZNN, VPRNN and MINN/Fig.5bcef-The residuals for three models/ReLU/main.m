
close all
clc
clear all
for iter=1:1
MINN;
ZNN;
VPRNN;
legend('MINN','ZNN','VPRNN');
set(gca,'FontName','Times New Roman','FontSize',16,'LineWidth',1.5);
end


