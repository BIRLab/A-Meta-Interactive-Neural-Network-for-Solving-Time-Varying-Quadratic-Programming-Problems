function y=AFReLU(E)
y=max(0,E);
