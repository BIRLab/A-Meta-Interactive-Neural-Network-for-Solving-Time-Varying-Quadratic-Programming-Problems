function y=AFSwish(E)

y=E./(1+exp(-E));
