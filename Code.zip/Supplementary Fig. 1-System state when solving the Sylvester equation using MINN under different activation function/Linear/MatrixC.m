function C=MatrixC(t)
C=[0.1*sin(t)*sin(t)-1 -0.2*cos(t)*cos(t);0.1*sin(t)*cos(t) 0.2*sin(t)*cos(t)-1];