function output=DiffC(t,x)
output=[0.2*sin(t)*cos(t) 0.4*cos(t)*sin(t);0.1*cos(2*t) 0.2*cos(2*t)];