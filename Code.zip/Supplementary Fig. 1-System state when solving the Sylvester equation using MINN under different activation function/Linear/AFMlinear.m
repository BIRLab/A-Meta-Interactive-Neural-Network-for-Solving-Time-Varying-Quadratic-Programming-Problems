function output=AFMlinear(E)
output=E;