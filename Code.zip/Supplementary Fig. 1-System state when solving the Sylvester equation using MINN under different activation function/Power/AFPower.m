function y=AFPower(E)
if nargin==1, p=3;
end
y=E.^p;
